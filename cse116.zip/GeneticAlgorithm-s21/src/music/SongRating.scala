package music

class SongRating(val rating: Int, val energy: Int) {

}
