package statistics

object Statistics {

  def average[T](data: List[T], f: T => Double): Double = {
    0.0
    // TODO: LT1
  }


}
