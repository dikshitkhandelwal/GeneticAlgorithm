package tests

import org.scalatest._

class LectureTask1 extends FunSuite {


  test("your test") {

  }


}
